<?php

$page=$_GET['page'];
$id=$_GET['id'];
switch($page){
	case 'input':
		$page="	include 'pages/input.php'; 
				include 'koneksi.php';";
		break;

	case 'view':
		$page=	"include 'pages/viewdata.php'; 
				include 'koneksi.php';";
		break;

	case 'logout':
		$page=	"include 'auth/logout.php'; 
				include 'koneksi.php';";
		break;

	case 'update':
		$page=	"include 'pages/viewupdate.php'; 
				include 'koneksi.php';";
		break;

	case 'caridata':
		$page=	"include 'pages/viewSearch.php'; 
				include 'koneksi.php';";
		break;
	case 'hapus':
		$page=	"include 'controller/hapus.php'; 
				include 'koneksi.php';";
		break;

	case 'queryupdate':
		$page=	"include 'controller/update.php'; 
				include 'koneksi.php';";
		break;
	
	case 'queryinsert':
		$page=	"include 'controller/insert.php'; 
				include 'koneksi.php';";
		break;

	default:
		$page=	"include 'pages/viewdata.php';
				include 'koneksi.php';";
		break;
}
$CONTENT_["main"]=$page;
?>
