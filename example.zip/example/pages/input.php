
<div style="margin: 20px;">

            <form role="form" action="?page=queryinsert" method="POST">
              <div class="box-body">
                <div class="form-group">
                  <label for="InputNama">Nama</label>
                  <input type="text" class="form-control" id="InputNama" name="txt_nama" placeholder="Masukan Nama">
                </div>
                <div class="form-group">
                  <label for="InputNim">Nim</label>
                  <input type="text" class="form-control" id="InputNim" name="txt_nim" placeholder="Masukan Nim">
                </div>
                <div class="form-group">
                  <label for="InputKelas">Kelas</label>
                  <input type="text" class="form-control" id="InputKelas" name="txt_kelas" placeholder="Masukan Kelas">
                </div>
              <div class="form-group">
              	Jenis Kelamin
                  <div class="radio">
                    <label>
                      <input type="radio" name="opt_gender" id="optionsRadios1" value="L">
                      Laki-Laki
                    </label>
                  </div>
                  <div class="radio">
                    <label>
                      <input type="radio" name="opt_gender" id="optionsRadios2" value="P" >
                      Perempuan
                    </label>
                  </div>
                  
                </div>

                <div class="form-group">
                Pilih Agama
                  <div class="select">
                    <br>
                   <select name="opt_agama">
                      <option value="ISLAM"> ISLAM </option>
                      <option value="PROTESTAN"> PROTESTAN </option>
                      <option value="HINDU"> HINDU </option>
                      <option value="BUDHA"> BUDHA </option>
                      <option value="KATOLIK"> KATOLIK </option>
                   </select>
                  </div>
                </div>


                
              </div>
              
                <button type="submit" class="btn btn-primary">Kirim</button>
                <button type="reset" class="pull-right btn btn-danger">Reset</button>

            </form>
          </div>

  
