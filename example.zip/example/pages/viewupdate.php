<?php
try {
    $selectedNim = $_GET['id'] ;
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pwd);
    $sql = "SELECT * from mhs where id = '".$selectedNim."' ";
    $result = $pdo->query($sql);
    $result->setFetchMode(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Koneksi $db bermasalah:" . $e->getMessage());
}
?>

  <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">Form Edit</h3>
            </div>
            <?php while ($row = $result->fetch()): ?>
            <div class="box-body">
            	<form action="?page=queryupdate" method="POST">
                <div class="col-xs-6">
                  <input type="text" name = "id_old" class="form-control" value="<?php echo $selectedNim;?>" readonly>
                </div>
                <div class="col-xs-6">
                  <input type="text" name="id" class="form-control" 
					placeholder="Masukan Id Baru (Optional)">
                </div>
              
         
                <div class="col-xs-12">
                 <div class="form-group">
                  <label for="nama">Nama </label>
                  <input type="text" class="form-control" id="nama" name="nama" 
                  placeholder="Masukan Nama" value="<?php echo $row['nama'];?>">
                </div>
                </div>

                <div class="col-xs-6">
                 <div class="form-group">
                  <label for="nim">Nim </label>
                  <input type="text" class="form-control" id="nim" 
                  placeholder="Masukan nim" name="nim" value="<?php echo $row['nim'];?>">
                </div>
                </div>
                <div class="col-xs-6">
                 <div class="form-group">
                  <label for="kelas">Kelas </label>
                  <input type="text" name="kelas" class="form-control" id="kelas" 
                  placeholder="Masukan nim" value="<?php echo $row['kelas'];?>">
                </div>
                </div>
               

               <div class="col-xs-6">
                 <div class="form-group">
                 <label> Pilih Jenis Kelamin </label>
                 <br>
                 <br>
                 <input type="radio" name="gender" value="L" 
                                <?php echo ($row['gender']=='L')?'checked':'' ?>>Laki Laki
                 <input type="radio" name="gender" value="P" 
                                <?php echo ($row['gender']=='P')?'checked':'' ?> >Perempuan
                </div>
                </div>

                <div class="col-xs-6">
                <div class="form-group">
                Pilih Agama : &nbsp; <?php echo $row['agama']; ?>
                  <div class="select">
                    <br>
                   
                   <select name="agama" >
                      <option value="ISLAM"> ISLAM </option>
                      <option value="PROTESTAN"> PROTESTAN </option>
                      <option value="HINDU"> HINDU </option>
                      <option value="BUDHA"> BUDHA </option>
                      <option value="KATOLIK"> KATOLIK </option>
                   </select>
                  </div>
                </div>
                </div>

                <div class="col-xs-12">
                <div class="form-group">
                <button type="submit" class="btn btn-primary">Kirim</button>
                  </div>
                </div>
                </div>
                
              </form>
            </div>
            <?php endwhile; ?>
            <!-- /.box-body -->
          </div>
