<?php
    
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pwd);
    $sql = "SELECT * from mhs";
    $q = $pdo->query($sql);
    $q->setFetchMode(PDO::FETCH_ASSOC);
?>


          <div class="box" style="margin: 20;">
            
            
              <div class="box-header">
              <h3 class="box-title">Tabel Mahasiswa</h3>

              <div class="box-tools">
                <form>
                <div class="input-group input-group-sm pull-right" style="width: 200px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search Nim / Nama">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default" formaction="?page=caridata" formmethod="post"><i class="fa fa-search"></i></button>
                  </div>
                </div>
                </form>
              </div>
            </div>
         
            
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tbody><tr>
                  <th>ID</th>
                  <th>Nama</th>
                  <th>Nim</th>
                  <th>Kelas</th>
                  <th>Agama</th>
                  <th>Aksi</th>
                </tr>
                    <?php while ($row = $q->fetch()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id']) ?></td>
                            <td><?php echo htmlspecialchars($row['nama']) ?></td>
                            <td><?php echo htmlspecialchars($row['nim']); ?></td>
                            <td><?php echo htmlspecialchars($row['kelas']); ?></td>
                            <td><?php echo htmlspecialchars($row['agama']); ?></td>
                            <td> 
                              <a class="btn" 
                              href="?page=update&amp;id=<?php echo $row['id'];?>">
                              <i class="fa fa-edit"></i> Edit
                              </a>
                              <a class="btn" data-toggle="modal" data-target="#modal-default">
                              <i class="fa fa-remove"></i> Hapus
                              </a>

                            </td>
                        </tr>
        <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Hapus Data</h4>
              </div>
              <div class="modal-body">
                <p>Data <?php echo htmlspecialchars($row['nama']) ?> Akan di hapus??&hellip;</p>
              </div>
              <div class="modal-footer">
               

                <a class="btn pull-left" href="?page=hapus&amp;id=<?php echo $row['id'];?>" 
                  data-dismiss="modal">
                  <i class="fa fa-minus"></i> No
                </a>
                <a class="btn" href="?page=hapus&amp;id=<?php echo $row['id'];?>">
                  <i class="fa fa-edit"></i> Yes
                </a>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
                    <?php endwhile; ?>
              </tbody>
            </table>
            </div>
          </div>
