<?php
try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pwd);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $insert_query=$conn->prepare("insert into mhs (nim, nama, kelas, gender, agama)
        values(:nim, :nama, :kelas, :gender, :agama)");
    $insert_query->bindParam(':nim', $_POST['txt_nim']);
    $insert_query->bindParam(':kelas', $_POST['txt_kelas']);
    $insert_query->bindParam(':nama', $_POST['txt_nama']);
    $insert_query->bindParam(':gender', $_POST['opt_gender']);
    $insert_query->bindParam(':agama', $_POST['opt_agama']);
    $insert_query->execute();
    echo 
    "<div class='col-lg-12 col-xs-12'>
          <!-- small box -->
          <div class='small-box bg-green'>
            <div class='inner'>
              <h4>".$insert_query->rowCount()." Data Berhasil di Tambahkan</h4>
              <p> &nbsp;  </p>
            </div>
            <div class='icon'>
              <i class='ion ion-person-add'></i>
            </div>
            <a href='?page=lihat' class='small-box-footer'>
              Lihat Data <i class='fa fa-arrow-circle-right'></i>
            </a>
          </div>
        </div>";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
?>