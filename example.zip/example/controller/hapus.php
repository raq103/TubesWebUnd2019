<?php
try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pwd);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
    $delete_query=$conn->prepare("delete from mhs WHERE id = :id");
    $delete_query->bindParam(':id', $_GET['id']);
    $delete_query->execute();
     echo 
    "<div class='col-lg-12 col-xs-12'>
          <!-- small box -->
          <div class='small-box bg-red'>
            <div class='inner'>
              <h4>".$delete_query->rowCount()." Data Berhasil di Hapus</h4>
              <p> &nbsp;  </p>
            </div>
            <div class='icon'>
              <i class='ion ion-person'></i>
            </div>
            <a href='?page=lihat' class='small-box-footer'>
              Lihat Data <i class='fa fa-arrow-circle-right'></i>
            </a>
          </div>
        </div>";
    }    
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
?>