<?php
try {
    if ($_POST['id'] === "") {
        $id = $_POST['id_old'];
    } else {
        $id = $_POST['id'];
    }
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pwd);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $update_query=$conn->prepare("UPDATE mhs set id = :id, nim = :nim, nama = :nama, 
        kelas = :kelas, agama = :agama,
        gender = :gender WHERE id = :id_old");
    $update_query->bindParam(':nim', $_POST['nim']);
    $update_query->bindParam(':nama', $_POST['nama']);
    $update_query->bindParam(':kelas', $_POST['kelas']);
    $update_query->bindParam(':gender', $_POST['gender']);
    $update_query->bindParam(':agama', $_POST['agama']);
    $update_query->bindParam(':id', $id);
    $update_query->bindParam(':id_old', $_POST['id_old']);
    $update_query->execute();

    echo 
    "<div class='col-lg-12 col-xs-12'>
          <!-- small box -->
          <div class='small-box bg-primary'>
            <div class='inner'>
              <h4>".$update_query->rowCount()." Data Berhasil di Update</h4>
              <p> &nbsp;  </p>
            </div>
            <div class='icon'>
              <i class='ion ion-person-add'></i>
            </div>
            <a href='?page=lihat' class='small-box-footer'>
              Lihat Data <i class='fa fa-arrow-circle-right'></i>
            </a>
          </div>
        </div>";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
?>