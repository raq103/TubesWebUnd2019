 <?php
 	$host = "localhost";
 	$db = "ryan";
 	$user = "root";
 	$pwd = "root";
	$conn = null;
?>