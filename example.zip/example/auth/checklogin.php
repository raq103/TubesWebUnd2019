<?php
if( (isset($_POST['username'])) || (isset($_POST['password']))  ) {
		session_start();
		if (($_POST['username'] == 'admin') && ($_POST['password'] == 'admin')) {
		$_SESSION['login_auth'] = true;
		exit("<script>window.location='../index.php?page=lihat';</script>");
		} else {
		$Confirmation = "<script> window.confirm('Username / Password Salah'); </script>";
		echo $Confirmation;
		    if ($Confirmation) {
		    $_SESSION['login_auth'] = false;
			exit("<script>window.history.back()</script>");
		    }
		}
} else
{
	exit("<script>window.history.back()</script>");
}
?>